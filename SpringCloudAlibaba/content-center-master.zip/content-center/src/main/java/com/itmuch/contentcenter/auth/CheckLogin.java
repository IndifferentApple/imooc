package com.itmuch.contentcenter.auth;

public @interface CheckLogin {
}
