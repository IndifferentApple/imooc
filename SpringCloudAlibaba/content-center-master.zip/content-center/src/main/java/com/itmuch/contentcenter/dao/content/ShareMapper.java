package com.itmuch.contentcenter.dao.content;

import com.itmuch.contentcenter.domain.entity.content.Share;
import tk.mybatis.mapper.common.Mapper;

public interface ShareMapper extends Mapper<Share> {
}