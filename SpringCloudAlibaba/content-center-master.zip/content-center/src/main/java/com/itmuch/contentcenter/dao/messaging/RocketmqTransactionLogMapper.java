package com.itmuch.contentcenter.dao.messaging;

import com.itmuch.contentcenter.domain.entity.messaging.RocketmqTransactionLog;
import tk.mybatis.mapper.common.Mapper;

public interface RocketmqTransactionLogMapper extends Mapper<RocketmqTransactionLog> {
}