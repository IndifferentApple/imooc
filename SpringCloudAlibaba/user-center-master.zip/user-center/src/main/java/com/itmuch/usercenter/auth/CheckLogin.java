package com.itmuch.usercenter.auth;

public @interface CheckLogin {
}
