package com.itmuch.usercenter.dao.bonus;

import com.itmuch.usercenter.domain.entity.bonus.BonusEventLog;
import tk.mybatis.mapper.common.Mapper;

public interface BonusEventLogMapper extends Mapper<BonusEventLog> {
}