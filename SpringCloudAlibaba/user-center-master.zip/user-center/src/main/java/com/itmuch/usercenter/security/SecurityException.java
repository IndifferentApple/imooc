package com.itmuch.usercenter.security;

public class SecurityException extends RuntimeException{
}
